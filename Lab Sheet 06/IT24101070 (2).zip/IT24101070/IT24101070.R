getwd()
setwd("C:\\Users\\USER\\Desktop\\IT24101070")
getwd()
#Q1
#part1
#Here, random variable X has binomial distribution with n= 50 and p= 0.85

#part2
1 - pbinom(47,50,0.85,lower.tail = FALSE)

##Q2
#part 01
#Random variable X =  number of calls received in one houren
 
##Part02
#Here, random variable X has poison distribution with lambda = 12

#Part03
dpois(15,12)

